Coloca aquí el archivo de la tipografía Everett (licencia requerida).

Ruta esperada por los estilos:
- `ibiza villa/FASE_5_ENTREGABLES_FINALES/WEB_AUDITORIA/fonts/everett.woff2`

Si el archivo no está disponible, los encabezados utilizarán la fuente de reserva definida: `Hanken Grotesk`, sans-serif.