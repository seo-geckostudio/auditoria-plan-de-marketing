# Plantillas CSV para Nuevos Módulos de Auditoría SEO

Este documento contiene las especificaciones de todas las plantillas CSV para los módulos nuevos añadidos a la auditoría.

## Ubicación de CSVs
Todos los archivos CSV deben guardarse en: `ibiza villa/FASE_5_ENTREGABLES_FINALES/WEB_AUDITORIA/data/`

## Formato General
- Separador: `,` (coma)
- Codificación: `UTF-8`
- Primera fila: encabezados exactos
- Fechas: formato ISO `YYYY-MM-DD`

---

## FASE 0: Brief y Planificación

### brief_proyecto.csv
```csv
campo,valor,validado,notas
Nombre de la Empresa,Example Corp,SI,Dominio: example.com
Sector,SaaS B2B,SI,Software de gestión empresarial
Productos Principales,"CRM, Marketing Automation",SI,3 productos principales
USP,Integración completa con IA,SI,Diferenciador clave
Historial SEO Previo,Agencia anterior 2020-2022,SI,No penalizaciones conocidas
Competidores Principales,"Competidor1, Competidor2, Competidor3",SI,Top 3 identificados
Posicionamiento Actual Percibido,Pagina 2-3 para keywords principales,SI,Necesita mejorar
Recursos Internos,1 dev + 1 content writer,SI,Disponibles 50% tiempo
Objetivos Cuantitativos,+50% tráfico orgánico en 6 meses,SI,20K a 30K visitas/mes
Timeline Esperado,6-12 meses,SI,Expectativas realistas
Geografías Objetivo,"España, LATAM",SI,Español primario
Público Objetivo,CMOs y Marketing Directors,SI,B2B decisores
CMS,WordPress,SI,Versión 6.4
Stack Tecnológico,"AWS, Cloudflare CDN",SI,Moderna infraestructura
```

### roadmap_auditoria.csv
```csv
fase,actividad,responsable,fecha_inicio,fecha_fin,estado,dependencias
FASE_0,Análisis de mercado,Analista Senior,2024-01-15,2024-01-19,completada,brief_validado
FASE_0,Investigación competencia,Analista SEO,2024-01-15,2024-01-19,completada,brief_validado
FASE_1,Validación de accesos,PM,2024-01-22,2024-01-24,completada,FASE_0
FASE_1,Setup herramientas,SEO Tech,2024-01-22,2024-01-24,completada,accesos_validados
FASE_2,Keyword research,SEO Specialist,2024-01-25,2024-01-31,en_progreso,FASE_1
FASE_2,Keyword mapping,SEO Specialist,2024-02-01,2024-02-05,pendiente,keyword_research
FASE_3,Análisis arquitectura,SEO Architect,2024-02-06,2024-02-12,pendiente,FASE_2
FASE_4,Auditoría técnica completa,Equipo completo,2024-02-13,2024-02-28,pendiente,FASE_3
FASE_5,Priorización tareas,PM + Analista,2024-03-01,2024-03-07,pendiente,FASE_4
FASE_6,Informe final,Equipo completo,2024-03-08,2024-03-15,pendiente,FASE_5
```

---

## FASE 2: Keyword Research

### keywords_actuales.csv
```csv
keyword,posicion_actual,volumen_busqueda,dificultad,url_ranking,impresiones,clics,ctr,tendencia
software crm empresarial,15,2400,68,/productos/crm,8500,320,3.76,estable
mejor crm para pymes,23,1800,55,/blog/mejores-crm,3200,85,2.66,creciente
crm marketing automation,8,1200,72,/productos/marketing,4800,380,7.92,creciente
precio crm empresarial,31,950,45,/pricing,1800,35,1.94,estable
crm gratis español,42,1500,38,/blog/crm-gratis,890,12,1.35,decreciente
```

### keywords_oportunidad.csv
```csv
keyword,volumen,dificultad,gap_competidores,potencial_trafico,prioridad
integración crm salesforce,880,52,3_competidores_top10,250,A
crm para equipos remotos,720,48,2_competidores_top5,180,A
automatización marketing b2b,1100,65,5_competidores_top10,150,B
crm con ia artificial,650,58,1_competidor_top10,140,A
comparativa crm 2024,950,54,4_competidores_top10,220,A
```

### keywords_competencia.csv
```csv
keyword,volumen,nuestra_posicion,competidor_1_pos,competidor_2_pos,competidor_3_pos,gap_score,tipo_contenido_ganador
software gestión clientes,3200,25,3,5,8,22,landing_page_producto
crm online empresas,1900,38,2,4,11,36,comparativa_detallada
automatizar ventas crm,1400,sin_rankear,1,7,9,100,guia_completa
crm nube empresarial,1100,45,5,6,12,40,caso_estudio
herramienta crm marketing,880,18,2,3,4,16,landing_caracteristicas
```

### share_of_voice.csv
```csv
categoria,nuestro_sov,competidor_sov,gap_porcentual,keywords_criticas
CRM_Empresarial,12.3,45.6,-33.3,"software crm, crm empresas, sistema crm"
Marketing_Automation,18.7,38.2,-19.5,"automatizacion marketing, email automation"
Integraciones,8.4,52.1,-43.7,"integracion crm, api crm, conectar crm"
Pricing_Comercial,22.5,35.8,-13.3,"precio crm, cuanto cuesta, planes crm"
```

### keywords_intencion.csv
```csv
keyword,volumen,intencion,funnel_stage,tipo_contenido_ideal,competencia_serp,features_serp,prioridad
que es un crm,4800,informacional,awareness,guia_completa,media,"paa,video",B
como elegir un crm,1200,informacional,consideration,comparativa,alta,"paa,featured_snippet",A
mejor crm para pymes,1800,comercial,consideration,review_comparativa,muy_alta,"local_pack,paa",A
precio software crm,950,transaccional,decision,pricing_page,alta,"featured_snippet",A
comprar licencia crm,320,transaccional,decision,producto_page,media,shopping,A
crm vs erp diferencias,680,informacional,awareness,articulo_vs,media,paa,B
```

### keyword_mapping.csv
```csv
keyword,url_actual,url_propuesta,tipo_pagina,accion_requerida,prioridad,notas
software crm empresarial,/productos/crm,/productos/crm,producto,optimizar_existente,A,Mejorar H1 y meta description
mejor crm pymes,/blog/crm-2023,/mejores-crm-pymes,landing_comercial,crear_nuevo,A,Crear landing específica comercial
crm marketing automation,/productos/marketing,/productos/marketing,producto,optimizar_existente,A,Añadir comparativa interna
integración crm,/blog/integraciones,/integraciones,hub_page,crear_nuevo,B,Crear hub de integraciones
precio crm,/pricing,/pricing,comercial,consolidar,A,Unificar con /planes
crm gratis español,sin_url,/crm-gratis-prueba,landing,crear_nuevo,B,Para captura leads trial
automatizar ventas,sin_url,/blog/automatizacion-ventas,guia,crear_nuevo,A,Long-form content
```

### quick_wins_keywords.csv
```csv
keyword,posicion_actual,volumen,potencial_trafico,accion_requerida,esfuerzo_estimado,impacto_esperado,prioridad_score
crm marketing automation,8,1200,180,optimizar_meta_title+añadir_faq,bajo,alto,95
software crm empresarial,15,2400,400,mejorar_h1+enriquecer_contenido+internal_links,medio,muy_alto,92
mejor crm para pymes,23,1800,250,crear_comparativa+schema_review,medio,alto,85
precio crm empresarial,31,950,120,optimizar_pricing_page+añadir_calculadora,bajo,medio,78
crm online para empresas,19,880,130,featured_snippet_optimization,bajo,medio,75
gestión clientes crm,12,720,100,añadir_caso_estudio+mejorar_cta,medio,medio,72
```

---

## SECCIÓN 09: SEO Moderno

### eeat_audit.csv
```csv
url,tipo_contenido,experience_score,expertise_score,authoritativeness_score,trust_score,mejoras_requeridas,prioridad
/blog/guia-crm-empresas,guia,6,7,5,8,"añadir_autor_bio+experiencia_real",A
/productos/crm,producto,7,8,6,9,"testimonios_clientes+casos_uso",A
/blog/mejor-crm-2024,review,4,6,5,7,"usar_producto_real+comparativa_profunda+autor_credenciales",A
/pricing,comercial,8,7,7,9,"testimonios+garantias+transparencia_costos",B
/sobre-nosotros,institucional,9,8,7,10,"premios+certificaciones+equipo_fotos_reales",B
```

### voice_search_keywords.csv
```csv
query_conversacional,volumen,intent,contenido_actual,contenido_propuesto,prioridad
cuál es el mejor crm para pequeñas empresas,720,comercial,/blog/mejores-crm,crear_faq_especifica,A
cómo funciona un sistema crm,1100,informacional,sin_contenido,crear_guia_how_it_works,A
qué crm es más fácil de usar,480,comercial,sin_contenido,añadir_seccion_ease_of_use,B
por qué necesito un crm para mi negocio,850,informacional,/blog/beneficios-crm,optimizar_para_voice,A
cuánto cuesta implementar un crm,620,transaccional,/pricing,añadir_faq_costos_implementacion,A
dónde puedo probar un crm gratis,380,transaccional,sin_contenido,crear_landing_trial,B
```

### video_seo.csv
```csv
video_url,titulo,descripcion_optimizada,keywords_target,schema_implementado,thumbnails,transcripcion,engagement,prioridad
/videos/demo-crm,Tutorial CRM 2024: Guía Completa,Aprende a usar nuestro CRM...,tutorial crm|guia crm,SI,custom_pro,SI,alto,A
youtube.com/watch?v=123,Cómo elegir el mejor CRM,En este video completo...,mejor crm|elegir crm,SI,custom_pro,SI,medio,A
/videos/integracion,Integrar CRM con Salesforce,Guía paso a paso...,integrar crm|salesforce,NO,auto,NO,bajo,B
```

### local_seo.csv
```csv
location,gbp_status,nap_consistency,citations_count,reviews_count,avg_rating,local_pack_appearances,prioridad
Madrid Centro,completo_optimizado,100%,45,127,4.8,15_keywords,A
Barcelona,completo_basico,95%,32,89,4.6,8_keywords,A
Valencia,incompleto,85%,18,34,4.5,3_keywords,B
Sevilla,sin_configurar,0%,5,12,4.2,0_keywords,C
```

---

## Templates de Uso

### Cómo usar estas plantillas:

1. **Copiar la plantilla** correspondiente al módulo que estás implementando
2. **Guardar como CSV** en la ruta especificada con el nombre exacto
3. **Completar con datos reales** extraídos de las fuentes indicadas
4. **Validar formato**: usar UTF-8, separadores correctos
5. **No inventar datos**: si una fuente no está disponible, documentar el motivo

### Ejemplo de proceso completo:

**Para Keyword Research:**
```bash
# 1. Extraer datos de GSC
# Exportar Performance report con queries y métricas

# 2. Extraer keywords de Ahrefs
# Organic Keywords report → Export to CSV

# 3. Consolidar en keywords_actuales.csv
# Combinar datos de ambas fuentes
# Calcular tendencia basada en datos históricos
# Priorizar por impacto potencial

# 4. Validar completitud
# Verificar que todas las columnas estén llenas
# Revisar consistencia de datos
# Documentar observaciones en notas
```

### Comandos útiles para validar CSVs:

```bash
# Verificar encoding UTF-8
file -i archivo.csv

# Contar filas (headers + datos)
wc -l archivo.csv

# Ver primeras 5 filas
head -n 5 archivo.csv

# Verificar estructura de columnas
head -n 1 archivo.csv | tr ',' '\n'
```

---

## Notas Importantes

- **Fechas**: Siempre usar formato ISO: 2024-01-15
- **Decimales**: Usar punto (.) no coma: 4.8 no 4,8
- **Text con comas**: Entrecomillar: "valor1, valor2, valor3"
- **URLs**: Sin espacios ni caracteres especiales no encodificados
- **Null values**: Usar "sin_datos" o "N/A" explícitamente

## Actualización

Estas plantillas deben actualizarse:
- **Semanalmente**: para keywords y rankings
- **Mensualmente**: para métricas de autoridad y enlaces
- **Trimestralmente**: para auditorías completas E-E-A-T
- **Ad-hoc**: tras updates de algoritmo o cambios mayores

---

*Última actualización: 2024-01-15*
*Versión: 2.0 - Incluye módulos modernos SEO 2024-2025*
