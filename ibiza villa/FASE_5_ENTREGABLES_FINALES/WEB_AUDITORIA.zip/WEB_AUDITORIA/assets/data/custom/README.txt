Coloca aquí los CSVs reales exportados desde GA4 con estos nombres exactos:

- organic_sessions_by_month_last12.csv (headers: date,sessions)
- organic_conversions_by_month_last12.csv (headers: date,conversions)
- channels_last365.csv (headers: date,channel,sessions)
- pages_sample.csv (headers: url,pageviews,sessions,conversions)
- pageviews_by_country_last30.csv (headers: country,pageviews)
- pageviews_by_device_last30.csv (headers: device,pageviews)
- search_engines_last30.csv (headers: source,sessions)
- visibility_index_project.csv (headers: date,index)
- visibility_comparison_project_vs_sector.csv (headers: date,project_index,sector_index)

Nota: No se automatiza GA4 en esta fase. Exporta manualmente desde GA4 y, si los encabezados del CSV de GA4 no coinciden, renómbralos para que coincidan con los indicados.